from pymongo import MongoClient


class AnimalShelter:
    """CRUD operations for AAC Animal collection in MongoDB"""

    def __init__(self, username='aacuser', password='Password123'):

        # -------------------------
        # Connection Settings
        # -------------------------
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # IMPORTANT FIX:
        # authSource=admin is REQUIRED or authentication will fail
        uri = (
            f"mongodb://{username}:{password}"
            f"@{HOST}:{PORT}/{DB}?authSource=admin"
        )

        try:
            self.client = MongoClient(uri)
            # quick connection test
            self.client.admin.command('ping')
        except Exception as e:
            print("MongoDB connection failed:", e)

        # Database + Collection
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # =========================
    # CREATE (C)
    # =========================
    def create(self, data):
        """
        Insert a document into MongoDB.
        Returns True if successful, False otherwise.
        """
        if data is None:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.inserted_id is not None
        except Exception as e:
            print("Create failed:", e)
            return False

    # =========================
    # READ (R)
    # =========================
    def read(self, query):
        """
        Query documents from MongoDB.
        Returns a list of results.
        """
        if query is None:
            query = {}

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print("Read failed:", e)
            return []

    # =========================
    # UPDATE (U)
    # =========================
    def update(self, query, update_data):
        """
        Update documents matching query.
        Returns number of modified documents.
        """
        if query is None or update_data is None:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        except Exception as e:
            print("Update failed:", e)
            return 0

    # =========================
    # DELETE (D)
    # =========================
    def delete(self, query):
        """
        Delete documents matching query.
        Returns number of deleted documents.
        """
        if query is None:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("Delete failed:", e)
            return 0